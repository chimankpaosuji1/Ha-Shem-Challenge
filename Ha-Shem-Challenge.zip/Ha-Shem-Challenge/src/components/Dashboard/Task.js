import React from 'react'



const Task = () => {
        return (
                <div >
                        <div className="container">

                                <div className="progress">
                                        <span className="title timer" data-from="0" data-to="85" data-speed="1800">85</span>
                                        <div className="overlay"></div>
                                        <div className="left"></div>
                                        <div className="right"></div>
                                </div>

                        </div>
                                
                </div>
        )
}

export default Task;