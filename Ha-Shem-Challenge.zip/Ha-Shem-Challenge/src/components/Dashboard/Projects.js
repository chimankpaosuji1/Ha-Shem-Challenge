import React from 'react'
import Inner1Project from './Inner1Project';
import Inner2Project from './Inner2Project';


const Projects = () => {

        return (
                <div>
                        <Inner1Project />
                        <Inner2Project />
                </div>
        )
}

export default Projects;